                           IMAGE SHUFFLE GAME SYNOPSIS

DESCRIPTION:

There would be an actual image and also there would be shuffled image segments of that original image.Game is to arrage those shuffled images into correct order to match with the original image.4X4 Grid view has been used for all the image segments.

METHODS USED:- 

1. click events has been used  to exchange the position of an image segment with a blank cell.

2. Segments of the images are named in row wise sequential order.(Example: For first Row:-"pacman_01.png[1,1]","pacman_02.png[1,2]"....."pacman_15.png[4,3]”).


CONCLUSION:-
Once each segment of image cell has been correctly placed and the actual image has been formed, an alert prompt will appear with  "CONGRATULATIONS" text.

