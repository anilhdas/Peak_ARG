                           SUDOKU GAME SYNOPSIS

DESCRIPTION:

The objective is to fill a 9×9 grid with digits so that each column, each row, and each of the nine 3×3 subgrids that compose the grid (also called "boxes", "blocks", "regions", or "subsquares") contains all of the digits from 1 to 9. The puzzle setter provides a partially completed grid, which for a well-posed puzzle has a unique solution.


CONCLUSION:-
Once the values has been correctly placed then background color of all the Correct cell will become 'Green',the wrong value cell's background color would become 'Red' and the empty boxes will be marked with 'Grey' background color.

